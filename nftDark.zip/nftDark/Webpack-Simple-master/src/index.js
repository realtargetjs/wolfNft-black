import 'normalize.css'
import './styles/main.scss';
import  './js/test.js'
